const initialState = {

  component: "tableList",
  category:['TEST'],
  question:'***THIS IS THE QUESTION FROM THE DATABASE*****',
  teams: ["team 1", "team 2", "team 3", "team 4", "team 5"],
  rounds: [1, 2, 3],
  test: ["one", "two", "three", "four", "sx"],
  status :['submitted'],
  answers:['java']
};
// let newState
export default function(state = initialState, action) {
  //   switch (action.type) {
  //     case "choose-component":
  //       newState = { ...state };
  //       newState.component = action.component;
  //       return newState;
  //     case "load-load-round":
  //       newState = { ...state };
  //       newState.catagories = [...action.payload];
  //       return newState;
  //      case "load-quistions":
  //       newState = { ...state };
  //       let quistions = [...state.quistions, action.payload];
  //       newState.quistions = quistions;
  //       return newState;
  //       case "load-quistions":
  //       newState = { ...state };
  //       let quistions = [...state.quistions, action.payload];
  //       newState.quistions = quistions;
  //       return newState;

  //   }
  return state;
}
