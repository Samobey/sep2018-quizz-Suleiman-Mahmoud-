import React, { Component } from "react";
import { connect } from "react-redux";
class questionStatus extends Component {
  state = {};
  render() {
    return (
      <div className="container">
        <h1 id="quizzer-title" className="text-primary text-center">
          Question in progress..
        </h1>

        <div className="row">
          <h4 className="col text-center">category : <div className="text-warning">{this.props.category}</div> </h4>
        </div>
        <div className="row">
          <div className="col-4 offset-4 text-center border 
          shadow-lg p-3 mb-5 bg-white rounded
          ">{this.props.question}</div>
        </div>
        <div className="row">
          <table class="table border">
            <thead class="thead-dark">
              <tr>
                <th scope="col">Teams</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody>
            {this.props.teams.map(team => (
              <tr>
                <td key={team}>{team}</td>

                
                  <td key={this.props.status}>{this.props.status}</td>
               
              </tr>
            ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    status: state.status,
    teams: state.teams,
    question:state.question,
    category:state.category
  };
};

export default connect(mapStateToProps)(questionStatus);
