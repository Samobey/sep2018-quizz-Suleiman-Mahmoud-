import React, { Component } from "react";
import { connect } from "react-redux";
class TableList extends Component {
  state = {};
  render() {
    return (
      <div className="container">
        <h1 id="quizzer-title" className="text-primary text-center">
          Score Board
        </h1>
        <table class="table">
          <thead class="thead-dark">
            <tr>
              <th scope="col">Teams</th>
              <th scope="col">Round 1</th>
              <th scope="col">Round 2</th>
              <th scope="col">Round 3</th>
              <th scope="col">Round Points</th>
              <th scope="col">Totale Score</th>
            </tr>
          </thead>
          <tbody>
            {this.props.teams.map(team => (
              <tr>
                <td key={team}>{team}</td>

                {this.props.test.map(team => (
                  <td key={team}>{team}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    test: state.test,
    teams: state.teams
  };
};

export default connect(mapStateToProps)(TableList);
