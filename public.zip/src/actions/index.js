import { loadRounds, loadTeams, loadQuistions } from "../data/asyncData";

export const chooseComponent = component => {
  return {
    type: "choose-component",
    component
  };
};

export const loadTeams = () => {
  return dispatch => {
    loadTeams()
      .then(team => {
        return dispatch({ type: "load-team", payload: team });
      })
      .catch(err => {
        dispatch({ type: "err", payload: err });
      });
  };
};

export const loadQuistions = () => {
  return dispatch => {
    loadQuistions()
      .then(quistions => {
        return dispatch({ type: "load-quistions", payload: quistions });
      })
      .catch(err => {
        dispatch({ type: "err", payload: err });
      });
  };
};

export const loadRounds = () => {
  return dispatch => {
    loadRounds()
      .then(round => {
        return dispatch({ type: "load-round", payload: round });
      })
      .catch(err => {
        dispatch({ type: "err", payload: err });
      });
  };
};
